from django.apps import AppConfig


class SImageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'S_image'
